

INSERT INTO MEDIATHEQUEDB.MEMBRE(nom, prenom, mail, mdp, est_admin) VALUES 
('Nguyen', 'Minh', 'kidty85@gmail.com', 'minh', true);
INSERT INTO MEDIATHEQUEDB.MEMBRE(nom, prenom, mail, mdp) VALUES 
('Nguyen', 'Jimmy', 'nguyenquangminh@hotmail.fr', 'minh'),
('Nguyen', 'Quang', 'kidtycool@yahoo.fr', 'kidty'),
('Mouhamad', 'Imame', 'imame93@gmail.com', 'sadique');


INSERT INTO MEDIATHEQUEDB.MEDIA(categorie, titre, annee, description, jours_pret) VALUES ('LIVRE', 'The Walking dead', '2016', 'Histoire de zombies', 10);
INSERT INTO MEDIATHEQUEDB.MEDIA(categorie, titre, annee, description, jours_pret) VALUES ('AUDIO', 'Les fleurs', '1956', 'Fleurs', 7);
INSERT INTO MEDIATHEQUEDB.MEDIA(categorie, titre, annee, description, jours_pret) VALUES ('VIDEO', 'Minions', '2015', 'Minions', 9);


INSERT INTO MEDIATHEQUEDB.STOCK(media_id, quantite) VALUES (1, 5);
INSERT INTO MEDIATHEQUEDB.STOCK(media_id, quantite) VALUES (2, 5);
INSERT INTO MEDIATHEQUEDB.STOCK(media_id, quantite) VALUES (3, 5);